import yaml
import json

def parse_yaml_to_jsonv1(input, output):
    yaml_file = open(input)
    configuration = yaml.safe_load(yaml_file)

    json_file = open(output, "w")
    json.dump(configuration, json_file, ensure_ascii=False, indent="    ")

parse_yaml_to_jsonv1("yaml.yaml", "raspisanie.json")

"""
Очевидно данный код работает лучше, так как его писали нормальные люди :/
Главное различие состоит в том, что у меня отступы немного не по ГОСТу
"""
