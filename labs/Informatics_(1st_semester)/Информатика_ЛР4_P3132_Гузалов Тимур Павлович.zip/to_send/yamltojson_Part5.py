from yamltojson_Part0 import *
from yamltojson_Part1 import *
from yamltojson_Part2 import *
import toml

# Конвертировать будем в toml потому что он весьма интересный и красивый ;3

file_toml = open('raspisanie.toml', 'w')

parsed_yaml = yamlToDict("yaml.yaml")


toml.dump(parsed_yaml, file_toml)

