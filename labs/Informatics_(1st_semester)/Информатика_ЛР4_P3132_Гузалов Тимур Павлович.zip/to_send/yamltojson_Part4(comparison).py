from yamltojson_Part0 import *
from yamltojson_Part1 import *
from yamltojson_Part2 import *
from yamltojson_Part3 import *
import time
 
start_time = time.time()
for i in range(100):
    parse_yaml_to_jsonv0("yaml.yaml", "output.json")
end_time = time.time()
 
print(f"Время выполнения базы: {end_time-start_time} секунд")
start_time = time.time()
for i in range(100):
    parse_yaml_to_jsonv1("yaml.yaml", "output.json")
end_time = time.time()
 
print(f"Время выполнения c библиотеками: {end_time-start_time} секунд")


start_time = time.time()
for i in range(100):
    parse_yaml_to_jsonv2("yaml.yaml", "output.json")
end_time = time.time()
 
print(f"Время выполнения с регулярками: {end_time-start_time} секунд")

start_time = time.time()
for i in range(100):
    parse_yaml_to_jsonv3("yaml.yaml", "output.json")
end_time = time.time()
 
print(f"Время выполнения +-нормального парсинга: {end_time-start_time} секунд")