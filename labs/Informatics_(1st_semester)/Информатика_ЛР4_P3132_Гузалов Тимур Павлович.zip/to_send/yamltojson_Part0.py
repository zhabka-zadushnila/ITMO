

def yamlToDict (filename):
    result = {"week_days": {}}
    with open(filename, 'r') as file:
        lines = file.readlines()
        lesson_number = -1
        for i in lines:
            if (len(i) - len(i.lstrip()) == 2):
                day= i.replace(':',"").replace('"','').replace(' ','').replace('\n','')
                result["week_days"][day] = []
                lesson_number = -1
            if (len(i) - len(i.lstrip()) == 4):
                lesson_number += 1
                result["week_days"][day].append({"lesson": {}})
            if (len(i) - len(i.lstrip()) == 8):
                result["week_days"][day][lesson_number][i.split(":")[0].strip()] = i.split(":")[1].replace(" ","").replace('"',"").replace("\n","")
                
    return result



print(yamlToDict("yaml.yaml"))

def DictToJSON(dictionary, level=0):
    json = "{\n"
    for key, value in dictionary.items():
        if isinstance(value, dict):
            json += level*'    '+'"' + key + '":' + DictToJSON(value, level+1) + ",\n"
        elif isinstance(value, list):
            json += level*'    '+ '"' + key + '":'+ ListToJSON(value, level+1) + ",\n"
        else:
            json += level*'    '+ '"' + key + '": "'+ str(value) + '",\n'
    json = json.rstrip(",\n") + "\n"+ level*'    '+"}"
    return json

def ListToJSON(list,level):
    json = "["
    for item in list:
        if isinstance(item, dict):
            json += DictToJSON(item, level+1) + ",\n"
        elif isinstance(item, list):
            json += ListToJSON(item, level+1) + ",\n"
        else:
            json += str(item) + ",\n"
    json = json.rstrip(",\n") + "]"
    return json


def parse_yaml_to_jsonv0(input,output):
    filw = open(output, "w")
    filw.write(DictToJSON(yamlToDict(input)))


parse_yaml_to_jsonv0("yaml.yaml", "raspisanie.json")