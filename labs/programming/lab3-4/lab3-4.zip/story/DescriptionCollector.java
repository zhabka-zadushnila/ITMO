package story;
import java.util.ArrayList;

public class DescriptionCollector {
    private ArrayList<Descriable> describeableList = new ArrayList<>();
    
    DescriptionCollector(){}
    DescriptionCollector(ArrayList<Descriable> describeableList){
        this.describeableList = describeableList;
    }
    
    public void addDescriable(Descriable describeable){
        describeableList.add(describeable);
    }

    public void addDescriableList(ArrayList<Descriable> describeableList){
        this.describeableList.addAll(describeableList);
    }

    public String collectDescriptions(){
        String returnString = "";
        for (var describeable : describeableList){
            returnString += describeable.Describe() + " \n";
        }
    return returnString;
    }
    static public String collectDescriptions(ArrayList<Descriable> describeableList){
        String returnString = "";
        for (var describeable : describeableList){
            returnString += describeable.Describe() + " \n";
        }
    return returnString;
    }
    


}
