package story;

public interface Descriable {
    String Describe();
}
