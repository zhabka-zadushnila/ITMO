package story;

public class Location implements Descriable{
    String name;
    String description;
    Furniture[] furnitures;
    AbstractCreature[] creatures;

    public Location(String name, Furniture[] furnitures) {
        this.name = name;
        this.furnitures = furnitures;
    }

    public String getName() {
        return name;
    }

    public Furniture[] getFurnitures() {
        return this.furnitures;
    }

    public void addCreature(AbstractCreature creature) {
        this.creatures = appendCreatures(creatures, creature);
    }

    public AbstractCreature[] getCreatures() {
        return this.creatures;
    }
    
    public String Describe() {
        String result = "";
        DescriptionCollector collector = new DescriptionCollector();
        for (AbstractCreature creature : this.creatures) {
            collector.addDescriable(creature);
        }
        for (Furniture furniture : this.furnitures) {
            collector.addDescriable(furniture);
        }

        return result;
        
    }

    public void deleteCreature(AbstractCreature creature) {
        AbstractCreature[] newCreatures = new AbstractCreature[this.creatures.length - 1];
        int index = 0;
        for(AbstractCreature c : this.creatures) {
            if(c!= creature) {
                newCreatures[index++] = c;
            }
        }
        this.creatures = newCreatures;
    }

    

    private AbstractCreature[] appendCreatures(AbstractCreature[] creatures, AbstractCreature creature) {
        AbstractCreature[] newCreatures = new AbstractCreature[creatures.length + 1];
        for(int i = 0; i < creatures.length; i++) {
            newCreatures[i] = creatures[i];
        }
        newCreatures[creatures.length] = creature;
        return newCreatures;

    }

}


