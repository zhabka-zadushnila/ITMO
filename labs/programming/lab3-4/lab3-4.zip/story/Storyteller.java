package story;

import java.util.ArrayList;

public class Storyteller {
    AbstractCreature[] creatures;
    ArrayList<Location> locations;

    Storyteller(AbstractCreature ... creatures){
        this.creatures = creatures;
        //getting all the locations from creatures
        for (AbstractCreature creature : creatures){
            Location location = creature.getLocation();
            for (Location iterLocation : locations){
                if (iterLocation == location){
                    continue;
                }
                locations.add(iterLocation);
            }
        }
    }

    public void addLocation(Location location){
        this.locations.add(location);
    }

    public void start(){
        System.out.println("История началась:");
        SkatertSamobranka skatert = new SkatertSamobranka("Скатерть-самобранка");
        skatert.fold();
    }



}
