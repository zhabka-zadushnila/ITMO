package story;
import java.util.ArrayList;
import java.util.Random;

public class Korotyshka extends AbstractCreature {

    ArrayList<String> thoughts = new ArrayList<String>();
    
    public Korotyshka(String name, String description, Location location){
        super(name, description, "Коротышка", location);

    }
    public Korotyshka(String name, String description, Location location, StateOf inState){
        super(name, description, "Коротышка", location);
        this.InState = inState;
    }

    public String getName(){
        return this.name;
    }
    
    public void addThought(String thought){
        thoughts.add(thought);
    }

    public void InvestigateLocation(Location location){
        System.out.print("Коротышка " + this.name + " осматривает " + location.getName() + " и натыкается на объект: ");
        /*for(Predmet predmet : location.getPredmets()){
            System.out.println("- " + predmet.getName());
        }*/
        Furniture[] objects = location.getFurnitures();
        System.out.println(objects[new Random().nextInt(objects.length)].Describe());
    }

    public void SuggestState(StateOf stateOf) throws NoKorotyshkasInRoomExcepion {
        AbstractCreature[] CreaturesAtLocation = location.getCreatures(); 
        for(AbstractCreature creature : CreaturesAtLocation){
            System.out.println("Коротышка " + this.name + " убеждает " + creature.getName() + " поменять состояние на " + stateOf.name());
            creature.ChangeState(stateOf);
        }
    }
    
    public void sayThought(){
        if (thoughts.isEmpty()){
            System.out.println("Коротышка " + this.name + " ни о чём не думает.");
        } else {
            System.out.println("Коротышка " + this.name + " думает: " + thoughts.get(new Random().nextInt(thoughts.size())));
        }
    }

    @Override
    public void Interact(AbstractCreature creature){
        System.out.println(this.name + " обнимает " + creature.getName());
    }

    public void InteractWithInteractive(Interactive obj){
        obj.Interact(this);
    }

}
