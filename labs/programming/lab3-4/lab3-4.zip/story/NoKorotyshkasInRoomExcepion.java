package story;
public class NoKorotyshkasInRoomExcepion extends RuntimeException {
    public NoKorotyshkasInRoomExcepion (String message){
        super(message);
    }
}